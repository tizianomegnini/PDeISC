const API = "http://localhost:3000/alumnos";
    let idAEliminar = null;
    const modal = new bootstrap.Modal(document.getElementById('deleteModal'));

    // Alternar tema
    document.getElementById('btnTheme').addEventListener('click', () => {
        const html = document.documentElement;
        const current = html.getAttribute('data-bs-theme');
        html.setAttribute('data-bs-theme', current === 'dark' ? 'light' : 'dark');
    });

    // Función global para mostrar alertas
    function showToast(msg, type = 'success') {
        const container = document.getElementById('toastContainer');
        const toast = document.createElement('div');
        toast.className = `toast align-items-center text-white bg-${type} show`;
        toast.innerHTML = `<div class="d-flex"><div class="toast-body">${msg}</div><button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast"></button></div>`;
        container.appendChild(toast);
        setTimeout(() => toast.remove(), 3000);
    }

    // Cargar datos
    async function cargar() {
        try {
            const res = await fetch(API, { method: 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify({ action: 'get' }) });
            const data = await res.json();
            const tabla = document.getElementById('tabla');
            tabla.innerHTML = data.map(a => `
                <tr>
                    <td class="ps-3">${a.id}</td>
                    <td>${a.nombre}</td>
                    <td>${a.apellido}</td>
                    <td>${a.edad}</td>
                    <td class="text-end pe-3">
                        <button class="btn btn-outline-danger btn-sm btn-action" onclick="prepararEliminacion(${a.id})">Eliminar</button>
                    </td>
                </tr>`).join('');
        } catch (e) { showToast('Error al conectar con la API', 'danger'); }
    }

    // Guardar nuevo
    document.getElementById('formAlumno').addEventListener('submit', async (e) => {
        e.preventDefault();
        const nombre = document.getElementById('nombre').value.trim();
        const apellido = document.getElementById('apellido').value.trim();
        const edad = parseInt(document.getElementById('edad').value);

        // Validaciones mejoradas
        if (nombre.length < 3 || apellido.length < 3) return showToast('Nombres muy cortos', 'warning');
        
        await fetch(API, { 
            method: 'POST', 
            headers: {'Content-Type': 'application/json'}, 
            body: JSON.stringify({ action: 'add', nombre, apellido, edad }) 
        });
        
        document.getElementById('formAlumno').reset();
        showToast('Alumno registrado');
        cargar();
    });

    function prepararEliminacion(id) {
        idAEliminar = id;
        modal.show();
    }

    document.getElementById('confirmDeleteBtn').addEventListener('click', async () => {
        await fetch(API, { 
            method: 'POST', 
            headers: {'Content-Type': 'application/json'}, 
            body: JSON.stringify({ action: 'delete', id: idAEliminar }) 
        });
        modal.hide();
        showToast('Alumno eliminado');
        cargar();
    });

    cargar();